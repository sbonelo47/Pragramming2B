﻿using Microsoft.EntityFrameworkCore;
using ClaimApp.Models;

namespace ClaimApp.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        { }

        public DbSet<Claim> Claims { get; set; }

        internal void SaveChanges()
        {
            throw new NotImplementedException();
        }
    }
}
