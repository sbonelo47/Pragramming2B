﻿using System.ComponentModel.DataAnnotations;

namespace ClaimApp.Models
{
    public class Claim
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string LecturerName { get; set; }

        [Required]
        public double HoursWorked { get; set; }

        [Required]
        public double HourlyRate { get; set; }

        public double TotalPayment => HoursWorked * HourlyRate;

        public string Status { get; set; } = "Pending"; // Pending, Approved, Rejected

        public string? DocumentPath { get; set; } // For uploaded documents
    }
}
