﻿using ClaimApp.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

[Authorize(Roles = "HR")]
public class HrController : Controller
{
    private readonly ApplicationDbContext _context;

    public HrController(ApplicationDbContext context)
    {
        _context = context;
    }

    public IActionResult Dashboard()
    {
        var claims = _context.Claims.Where(c => c.Status == "Approved").ToList();
        return View(claims);
    }
}
