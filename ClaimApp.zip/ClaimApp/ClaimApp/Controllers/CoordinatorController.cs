﻿using ClaimApp.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

[Authorize(Roles = "Coordinator")]
public class CoordinatorController : Controller
{
    private readonly ApplicationDbContext _context;

    public CoordinatorController(ApplicationDbContext context)
    {
        _context = context;
    }

    public IActionResult Dashboard()
    {
        var claims = _context.Claims.Where(c => c.Status == "Pending").ToList();
        return View(claims);
    }
}
