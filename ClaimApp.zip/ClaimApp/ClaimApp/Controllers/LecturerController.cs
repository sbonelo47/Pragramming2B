﻿using ClaimApp.Data;
using ClaimApp.Models;
using Microsoft.AspNetCore.Mvc;

public class LecturerController : Controller
{
    private readonly ApplicationDbContext _context;

    public LecturerController(ApplicationDbContext context)
    {
        _context = context;
    }

    [HttpGet]
    public IActionResult SubmitClaim()
    {
        return View();
    }

    [HttpPost]
    public IActionResult SubmitClaim(Claim claim, IFormFile? file)
    {
        if (file != null)
        {
            string uploadsFolder = Path.Combine("wwwroot/uploads");
            Directory.CreateDirectory(uploadsFolder);
            string filePath = Path.Combine(uploadsFolder, file.FileName);

            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                file.CopyTo(stream);
            }

            claim.DocumentPath = "/uploads/" + file.FileName;
        }

        if (ModelState.IsValid)
        {
            _context.Claims.Add(claim);
            _context.SaveChanges();
            return RedirectToAction("ClaimSuccess");
        }

        return View(claim);
    }

    public IActionResult ClaimSuccess()
    {
        return View();
    }
}
