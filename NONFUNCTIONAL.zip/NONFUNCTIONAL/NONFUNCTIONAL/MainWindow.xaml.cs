﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace NONFUNCTIONAL.LecturerClaimsManagement
{
    // Main class containing all models and components
    public class MainClass
    {
        // Model classes
        public class Claim
        {
            public int Id { get; set; }
            public string LecturerName { get; set; }
            public string Course { get; set; }
            public DateTime Date { get; set; }
            public decimal Amount { get; set; }
            public string Status { get; set; } // "Pending", "Approved", "Rejected"
        }

        public class User
        {
            public int Id { get; set; }
            public string Name { get; set; }
            public string Role { get; set; } // "Lecturer", "Coordinator", "Manager"
        }

        public class Document
        {
            public int Id { get; set; }
            public string FileName { get; set; }
            public byte[] Content { get; set; }
        }

        // XAML-based Window class definition
        public class MainWindow : Window
        {
            public MainWindow()
            {
                InitializeComponent();
            }

            private void InitializeComponent()
            {
                this.Title = "Contract Monthly Claim System";
                this.Height = 700;
                this.Width = 1000;

                var grid = new Grid();
                var tabControl = new TabControl();

                // Define tabs, layout, and controls (non-functional placeholders)
                // Lecturer Tab for Submitting Claims
                var tabItemSubmitClaim = new TabItem { Header = "Submit Claim" };
                var stackPanelSubmitClaim = new StackPanel { Margin = new Thickness(10) };
                tabItemSubmitClaim.Content = stackPanelSubmitClaim;
                tabControl.Items.Add(tabItemSubmitClaim);

                // Programme Coordinator/Academic Manager Tab for Verifying Claims
                var tabItemVerifyClaims = new TabItem { Header = "Verify Claims" };
                var stackPanelVerifyClaims = new StackPanel { Margin = new Thickness(10) };
                tabItemVerifyClaims.Content = stackPanelVerifyClaims;
                tabControl.Items.Add(tabItemVerifyClaims);

                // Document Upload Tab
                var tabItemUploadDocument = new TabItem { Header = "Upload Document" };
                var stackPanelUploadDocument = new StackPanel { Margin = new Thickness(10) };
                tabItemUploadDocument.Content = stackPanelUploadDocument;
                tabControl.Items.Add(tabItemUploadDocument);

                // Track Claims Status Tab
                var tabItemTrackClaimStatus = new TabItem { Header = "Track Claim Status" };
                var stackPanelTrackClaimStatus = new StackPanel { Margin = new Thickness(10) };
                tabItemTrackClaimStatus.Content = stackPanelTrackClaimStatus;
                tabControl.Items.Add(tabItemTrackClaimStatus);

                grid.Children.Add(tabControl);
                this.Content = grid;
            }
        }
    }
}
