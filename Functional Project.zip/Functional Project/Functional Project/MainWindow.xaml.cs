﻿using Microsoft.Win32; // For file dialogs
using System;
using System.Collections.Generic;
using System.IO;
using System.Windows;

namespace CMCS
{
    public partial class MainWindow : Window
    {
        private List<Claim> pendingClaims = new List<Claim>();
        private string uploadedFileName;

        public MainWindow()
        {
            InitializeComponent();
            UpdatePendingClaimsList();
        }

        // Claim Submission Logic
        private void SubmitButton_Click(object sender, RoutedEventArgs e)
        {
            string facultyRole = facultyRoleComboBox.Text;
            string notes = notesTextBox.Text;
            string hoursWorkedText = hoursWorkedTextBox.Text;
            string hourlyRateText = hourlyRateTextBox.Text;

            // Input validation
            if (string.IsNullOrEmpty(facultyRole) || string.IsNullOrEmpty(notes) ||
                string.IsNullOrEmpty(uploadedFileName) || string.IsNullOrEmpty(hoursWorkedText) || string.IsNullOrEmpty(hourlyRateText))
            {
                MessageBox.Show("Please fill all fields, including hours worked, hourly rate, and upload a document.");
                return;
            }

            if (!double.TryParse(hoursWorkedText, out double hoursWorked) || hoursWorked <= 0)
            {
                MessageBox.Show("Please enter a valid number for hours worked (greater than 0).");
                return;
            }

            if (!decimal.TryParse(hourlyRateText, out decimal hourlyRate) || hourlyRate <= 0)
            {
                MessageBox.Show("Please enter a valid number for the hourly rate.");
                return;
            }

            Claim newClaim = new Claim
            {
                FacultyRole = facultyRole,
                Notes = notes,
                HoursWorked = hoursWorked,
                HourlyRate = hourlyRate,
                DocumentPath = uploadedFileName,
                Status = "Pending"
            };

            pendingClaims.Add(newClaim);
            MessageBox.Show("Claim submitted successfully!");

            // Reset form fields
            facultyRoleComboBox.SelectedIndex = -1;
            notesTextBox.Clear();
            hoursWorkedTextBox.Clear();
            hourlyRateTextBox.Clear();
            uploadedFileName = string.Empty;
            uploadedFileNameTextBlock.Text = string.Empty;

            UpdatePendingClaimsList();
        }

        // Approve/Reject Logic
        private void ApproveButton_Click(object sender, RoutedEventArgs e)
        {
            ProcessClaim("Approved");
        }

        private void RejectButton_Click(object sender, RoutedEventArgs e)
        {
            ProcessClaim("Rejected");
        }

        private void ProcessClaim(string action)
        {
            if (pendingClaimsListBox.SelectedItem is Claim selectedClaim)
            {
                selectedClaim.Status = action;
                MessageBox.Show($"Claim {action}!");
                UpdatePendingClaimsList();
                UpdateStatusList();
            }
            else
            {
                MessageBox.Show("Please select a claim to process.");
            }
        }

        // Document Upload Logic
        private void UploadButton_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Filter = "Documents (*.pdf; *.docx; *.xlsx)|*.pdf; *.docx; *.xlsx"
            };

            if (openFileDialog.ShowDialog() == true)
            {
                uploadedFileName = openFileDialog.FileName;
                uploadedFileNameTextBlock.Text = Path.GetFileName(uploadedFileName);
            }
        }

        // Update Lists
        private void UpdatePendingClaimsList()
        {
            pendingClaimsListBox.Items.Clear();
            foreach (var claim in pendingClaims)
            {
                if (claim.Status == "Pending")
                {
                    pendingClaimsListBox.Items.Add(claim);
                }
            }
        }

        private void UpdateStatusList()
        {
            statusListBox.Items.Clear();
            foreach (var claim in pendingClaims)
            {
                statusListBox.Items.Add($"{claim.FacultyRole}: {claim.Status}");
            }
        }
    }

    // Claim class
    public class Claim
    {
        public string FacultyRole { get; set; }
        public string Notes { get; set; }
        public double HoursWorked { get; set; }
        public decimal HourlyRate { get; set; }
        public string DocumentPath { get; set; }
        public string Status { get; set; }

        public override string ToString()
        {
            return $"{FacultyRole} - {Notes}, {HoursWorked} hours @ {HourlyRate:C} [{Status}]";
        }
    }
}
